import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    const { data: { user } } = await supabaseClient.auth.getUser()
    if (!user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const { videoId, action, data } = await req.json()

    switch (action) {
      case 'view':
        // Record video view
        await supabaseClient
          .from('user_videos')
          .update({ views: data.views + 1 })
          .eq('id', videoId)

        // Update analytics
        const today = new Date().toISOString().split('T')[0]
        await supabaseClient
          .from('video_analytics')
          .upsert({
            video_id: videoId,
            date: today,
            views: 1,
            unique_viewers: 1
          }, {
            onConflict: 'video_id,date',
            ignoreDuplicates: false
          })
        break

      case 'like':
        // Handle like/dislike
        await supabaseClient
          .from('video_likes')
          .upsert({
            user_id: user.id,
            video_id: videoId,
            is_like: data.isLike
          })
        break

      case 'watch_time':
        // Record watch time
        await supabaseClient
          .from('watch_history')
          .upsert({
            user_id: user.id,
            video_id: videoId,
            watch_duration: data.duration,
            completed: data.completed
          })
        break
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})