import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          avatar_url: string | null;
          username: string | null;
          bio: string | null;
          website: string | null;
          subscribers_count: number;
          videos_count: number;
          verified: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          avatar_url?: string | null;
          username?: string | null;
          bio?: string | null;
          website?: string | null;
          subscribers_count?: number;
          videos_count?: number;
          verified?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          avatar_url?: string | null;
          username?: string | null;
          bio?: string | null;
          website?: string | null;
          subscribers_count?: number;
          videos_count?: number;
          verified?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      user_videos: {
        Row: {
          id: string;
          user_id: string;
          bunny_video_id: string;
          title: string;
          description: string | null;
          thumbnail_url: string | null;
          duration: number;
          views: number;
          likes: number;
          dislikes: number;
          category: string;
          tags: string[];
          is_public: boolean;
          is_premium: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          bunny_video_id: string;
          title: string;
          description?: string | null;
          thumbnail_url?: string | null;
          duration?: number;
          views?: number;
          likes?: number;
          dislikes?: number;
          category?: string;
          tags?: string[];
          is_public?: boolean;
          is_premium?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          bunny_video_id?: string;
          title?: string;
          description?: string | null;
          thumbnail_url?: string | null;
          duration?: number;
          views?: number;
          likes?: number;
          dislikes?: number;
          category?: string;
          tags?: string[];
          is_public?: boolean;
          is_premium?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      subscriptions: {
        Row: {
          id: string;
          subscriber_id: string;
          channel_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          subscriber_id: string;
          channel_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          subscriber_id?: string;
          channel_id?: string;
          created_at?: string;
        };
      };
      video_likes: {
        Row: {
          id: string;
          user_id: string;
          video_id: string;
          is_like: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          video_id: string;
          is_like: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          video_id?: string;
          is_like?: boolean;
          created_at?: string;
        };
      };
      comments: {
        Row: {
          id: string;
          user_id: string;
          video_id: string;
          content: string;
          parent_id: string | null;
          likes: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          video_id: string;
          content: string;
          parent_id?: string | null;
          likes?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          video_id?: string;
          content?: string;
          parent_id?: string | null;
          likes?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      watch_history: {
        Row: {
          id: string;
          user_id: string;
          video_id: string;
          watched_at: string;
          watch_duration: number;
        };
        Insert: {
          id?: string;
          user_id: string;
          video_id: string;
          watched_at?: string;
          watch_duration?: number;
        };
        Update: {
          id?: string;
          user_id?: string;
          video_id?: string;
          watched_at?: string;
          watch_duration?: number;
        };
      };
    };
  };
};