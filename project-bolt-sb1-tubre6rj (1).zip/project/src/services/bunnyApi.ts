const BUNNY_API_KEY = '7cfa21d8-b15f-4c47-b9115e9704fd-e325-44fa';
const BUNNY_BASE_URL = 'https://video.bunnycdn.com';
const LIBRARY_ID = '466744';

export class BunnyVideoService {
  private static headers = {
    'AccessKey': BUNNY_API_KEY,
    'Content-Type': 'application/json',
  };

  static async getVideos(page = 1, itemsPerPage = 24): Promise<any> {
    try {
      const response = await fetch(
        `${BUNNY_BASE_URL}/library/${LIBRARY_ID}/videos?page=${page}&itemsPerPage=${itemsPerPage}`,
        {
          headers: this.headers,
        }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error fetching videos:', error);
      return { items: [], totalItems: 0 };
    }
  }

  static async getVideo(videoId: string): Promise<any> {
    try {
      const response = await fetch(
        `${BUNNY_BASE_URL}/library/${LIBRARY_ID}/videos/${videoId}`,
        {
          headers: this.headers,
        }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error fetching video:', error);
      return null;
    }
  }

  static async searchVideos(query: string): Promise<any> {
    try {
      const response = await fetch(
        `${BUNNY_BASE_URL}/library/${LIBRARY_ID}/videos?search=${encodeURIComponent(query)}`,
        {
          headers: this.headers,
        }
      );
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error searching videos:', error);
      return { items: [] };
    }
  }

  static getVideoPlayUrl(videoId: string): string {
    return `https://iframe.mediadelivery.net/embed/${LIBRARY_ID}/${videoId}`;
  }

  static getThumbnailUrl(videoId: string, thumbnailFileName?: string): string {
    if (thumbnailFileName) {
      return `https://vz-${LIBRARY_ID}.b-cdn.net/${videoId}/${thumbnailFileName}`;
    }
    return `https://vz-${LIBRARY_ID}.b-cdn.net/${videoId}/thumbnail.jpg`;
  }
}