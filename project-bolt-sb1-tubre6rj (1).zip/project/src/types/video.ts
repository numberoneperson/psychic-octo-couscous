export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  duration: number;
  views: number;
  likes: number;
  uploadDate: string;
  author: {
    name: string;
    avatar: string;
    subscribers: number;
    verified: boolean;
  };
  tags: string[];
  category: string;
  quality: string[];
  isLive?: boolean;
  isPremium?: boolean;
}

export interface BunnyVideo {
  guid: string;
  title: string;
  videoLibraryId: number;
  thumbnailFileName: string;
  length: number;
  views: number;
  dateUploaded: string;
  status: number;
}

export interface SearchFilters {
  query: string;
  sortBy: 'date' | 'views' | 'title' | 'duration' | 'likes';
  category: string;
  duration: 'any' | 'short' | 'medium' | 'long';
  uploadDate: 'any' | 'hour' | 'today' | 'week' | 'month' | 'year';
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  thumbnail: string;
  videoCount: number;
  videos: Video[];
  isPublic: boolean;
  createdAt: string;
}

export interface Comment {
  id: string;
  author: {
    name: string;
    avatar: string;
  };
  content: string;
  timestamp: string;
  likes: number;
  replies: Comment[];
}