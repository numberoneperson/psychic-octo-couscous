export const APP_CONFIG = {
  name: 'StreamVibe',
  description: 'Your Ultimate Video Streaming Platform',
  version: '2.0.0',
};

export const COLORS = {
  primary: '#8B5CF6',
  secondary: '#3B82F6',
  accent: '#F59E0B',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  gray: {
    50: '#F9FAFB',
    100: '#F3F4F6',
    200: '#E5E7EB',
    300: '#D1D5DB',
    400: '#9CA3AF',
    500: '#6B7280',
    600: '#4B5563',
    700: '#374151',
    800: '#1F2937',
    900: '#111827',
  },
};

export const BREAKPOINTS = {
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  '2xl': '1536px',
};

export const VIDEO_CATEGORIES = [
  'All',
  'Music',
  'Gaming',
  'Education',
  'Entertainment',
  'Sports',
  'Technology',
  'Travel',
  'Food',
  'Fashion',
  'News',
  'Comedy',
  'Science',
  'Art',
  'Lifestyle',
];

export const SORT_OPTIONS = [
  { value: 'date', label: 'Upload Date' },
  { value: 'views', label: 'View Count' },
  { value: 'likes', label: 'Most Liked' },
  { value: 'title', label: 'Title A-Z' },
  { value: 'duration', label: 'Duration' },
];

export const DURATION_FILTERS = [
  { value: 'any', label: 'Any Duration' },
  { value: 'short', label: 'Under 4 minutes' },
  { value: 'medium', label: '4-20 minutes' },
  { value: 'long', label: 'Over 20 minutes' },
];

export const UPLOAD_DATE_FILTERS = [
  { value: 'any', label: 'Any Time' },
  { value: 'hour', label: 'Last Hour' },
  { value: 'today', label: 'Today' },
  { value: 'week', label: 'This Week' },
  { value: 'month', label: 'This Month' },
  { value: 'year', label: 'This Year' },
];

export const MOCK_VIDEOS = [
  {
    id: '1',
    title: 'Amazing Nature Documentary: Wildlife in 4K',
    description: 'Explore the wonders of nature in this stunning 4K documentary featuring incredible wildlife footage from around the world.',
    thumbnail: 'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    videoUrl: '',
    duration: 1800,
    views: 125000,
    likes: 8500,
    uploadDate: '2024-01-15',
    author: {
      name: 'Nature Channel',
      avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=1',
      subscribers: 2500000,
      verified: true,
    },
    tags: ['nature', 'documentary', 'wildlife', '4k'],
    category: 'Education',
    quality: ['1080p', '4K'],
  },
  {
    id: '2',
    title: 'Modern Web Development: React & TypeScript Masterclass',
    description: 'Learn the latest in React and TypeScript development with this comprehensive tutorial covering hooks, state management, and best practices.',
    thumbnail: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    videoUrl: '',
    duration: 2400,
    views: 89000,
    likes: 5200,
    uploadDate: '2024-01-20',
    author: {
      name: 'Code Academy Pro',
      avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=1',
      subscribers: 1800000,
      verified: true,
    },
    tags: ['programming', 'tutorial', 'react', 'typescript'],
    category: 'Technology',
    quality: ['720p', '1080p'],
  },
  {
    id: '3',
    title: 'Epic Gaming Montage: Best Moments 2024',
    description: 'The most incredible gaming moments and highlights from 2024. Featuring amazing plays, epic wins, and unforgettable moments.',
    thumbnail: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    videoUrl: '',
    duration: 900,
    views: 340000,
    likes: 15600,
    uploadDate: '2024-01-25',
    author: {
      name: 'GameMaster',
      avatar: 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=1',
      subscribers: 950000,
      verified: true,
    },
    tags: ['gaming', 'montage', 'highlights', 'epic'],
    category: 'Gaming',
    quality: ['720p', '1080p'],
  },
  {
    id: '4',
    title: 'Relaxing Jazz Music for Study & Work',
    description: 'Perfect background music for studying, working, or relaxing. Smooth jazz instrumentals to help you focus and unwind.',
    thumbnail: 'https://images.pexels.com/photos/164821/pexels-photo-164821.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    videoUrl: '',
    duration: 3600,
    views: 78000,
    likes: 3200,
    uploadDate: '2024-01-18',
    author: {
      name: 'Jazz Lounge',
      avatar: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=1',
      subscribers: 650000,
      verified: false,
    },
    tags: ['music', 'jazz', 'relaxing', 'study'],
    category: 'Music',
    quality: ['720p', '1080p'],
  },
];

export const TRENDING_VIDEOS = [
  {
    id: 'trending-1',
    title: 'Breaking: Major Tech Announcement',
    views: 2500000,
    uploadDate: '2024-01-26',
    thumbnail: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&dpr=1',
  },
  {
    id: 'trending-2',
    title: 'Viral Dance Challenge Goes Global',
    views: 1800000,
    uploadDate: '2024-01-25',
    thumbnail: 'https://images.pexels.com/photos/1701194/pexels-photo-1701194.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&dpr=1',
  },
  {
    id: 'trending-3',
    title: 'Amazing Science Experiment',
    views: 950000,
    uploadDate: '2024-01-24',
    thumbnail: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&dpr=1',
  },
];