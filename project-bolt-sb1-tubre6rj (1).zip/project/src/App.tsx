import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { VideoGrid } from './components/VideoGrid';
import { VideoPlayer } from './components/VideoPlayer';
import { CategoryFilter } from './components/CategoryFilter';
import { UploadModal } from './components/UploadModal';
import { AdvancedFilters } from './components/AdvancedFilters';
import { TrendingSection } from './components/TrendingSection';
import { AuthModal } from './components/AuthModal';
import { UserProfile } from './components/UserProfile';
import { AdvancedSearch } from './components/AdvancedSearch';
import { Video, SearchFilters } from './types/video';
import { BunnyVideoService } from './services/bunnyApi';
import { MOCK_VIDEOS } from './utils/constants';
import { useAuth } from './hooks/useAuth';
import { PlaylistManager } from './components/PlaylistManager';
import { supabase } from './lib/supabase';

function App() {
  const { user, loading: authLoading, error: authError } = useAuth();
  const [videos, setVideos] = useState<Video[]>([]);
  const [filteredVideos, setFilteredVideos] = useState<Video[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isAdvancedSearchOpen, setIsAdvancedSearchOpen] = useState(false);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);
  const [selectedVideoForPlaylist, setSelectedVideoForPlaylist] = useState<string | null>(null);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [showTrending, setShowTrending] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearchMode, setIsSearchMode] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    sortBy: 'date',
    category: 'All',
    duration: 'any',
    uploadDate: 'any',
  });

  useEffect(() => {
    if (!authLoading) {
      loadVideos();
    }
  }, [authLoading]);

  useEffect(() => {
    if (!isSearchMode) {
      filterVideos();
    }
  }, [videos, filters, selectedCategory, isSearchMode]);

  const loadVideos = async () => {
    setIsLoading(true);
    try {
      // Try to load from Bunny.net API first
      const bunnyResponse = await BunnyVideoService.getVideos();
      
      if (bunnyResponse.items && bunnyResponse.items.length > 0) {
        // Convert Bunny.net videos to our format
        const bunnyVideos: Video[] = bunnyResponse.items.map((item: any) => ({
          id: item.guid,
          title: item.title || 'Untitled Video',
          description: 'Professional video content delivered through Bunny.net\'s global CDN for optimal streaming performance.',
          thumbnail: BunnyVideoService.getThumbnailUrl(item.guid, item.thumbnailFileName),
          videoUrl: BunnyVideoService.getVideoPlayUrl(item.guid),
          duration: item.length || 0,
          views: item.views || Math.floor(Math.random() * 100000),
          likes: Math.floor(Math.random() * 5000),
          uploadDate: item.dateUploaded || new Date().toISOString(),
          author: {
            name: 'StreamVibe Creator',
            avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=1',
            subscribers: Math.floor(Math.random() * 1000000),
            verified: Math.random() > 0.5,
          },
          tags: ['video', 'streaming', 'bunny'],
          category: 'Entertainment',
          quality: ['720p', '1080p'],
        }));
        setVideos([...bunnyVideos, ...MOCK_VIDEOS]);
      } else {
        // Fallback to mock videos if no Bunny.net videos
        setVideos(MOCK_VIDEOS);
      }
    } catch (error) {
      console.error('Error loading videos:', error);
      // Fallback to mock videos on error
      setVideos(MOCK_VIDEOS);
    } finally {
      setIsLoading(false);
    }
  };

  const filterVideos = () => {
    let filtered = videos;

    // Filter by search query
    if (filters.query.trim()) {
      filtered = filtered.filter(
        (video) =>
          video.title.toLowerCase().includes(filters.query.toLowerCase()) ||
          video.description.toLowerCase().includes(filters.query.toLowerCase()) ||
          video.author.name.toLowerCase().includes(filters.query.toLowerCase()) ||
          video.tags.some((tag) => tag.toLowerCase().includes(filters.query.toLowerCase()))
      );
    }

    // Filter by category
    const categoryToFilter = selectedCategory !== 'All' ? selectedCategory : filters.category;
    if (categoryToFilter !== 'All') {
      filtered = filtered.filter((video) =>
        video.category.toLowerCase() === categoryToFilter.toLowerCase() ||
        video.tags.some((tag) => tag.toLowerCase() === categoryToFilter.toLowerCase())
      );
    }

    // Filter by duration
    if (filters.duration !== 'any') {
      filtered = filtered.filter((video) => {
        switch (filters.duration) {
          case 'short':
            return video.duration < 240; // Under 4 minutes
          case 'medium':
            return video.duration >= 240 && video.duration <= 1200; // 4-20 minutes
          case 'long':
            return video.duration > 1200; // Over 20 minutes
          default:
            return true;
        }
      });
    }

    // Filter by upload date
    if (filters.uploadDate !== 'any') {
      const now = new Date();
      filtered = filtered.filter((video) => {
        const uploadDate = new Date(video.uploadDate);
        const diffTime = now.getTime() - uploadDate.getTime();
        const diffDays = diffTime / (1000 * 60 * 60 * 24);

        switch (filters.uploadDate) {
          case 'hour':
            return diffTime < 60 * 60 * 1000; // Last hour
          case 'today':
            return diffDays < 1; // Today
          case 'week':
            return diffDays < 7; // This week
          case 'month':
            return diffDays < 30; // This month
          case 'year':
            return diffDays < 365; // This year
          default:
            return true;
        }
      });
    }

    // Sort videos
    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case 'views':
          return b.views - a.views;
        case 'likes':
          return b.likes - a.likes;
        case 'title':
          return a.title.localeCompare(b.title);
        case 'duration':
          return b.duration - a.duration;
        case 'date':
        default:
          return new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime();
      }
    });

    setFilteredVideos(filtered);
  };

  const handleSearch = async (query: string) => {
    setFilters({ ...filters, query });
    
    if (query.trim()) {
      setIsLoading(true);
      try {
        // Search in Bunny.net if query exists
        const searchResponse = await BunnyVideoService.searchVideos(query);
        if (searchResponse.items && searchResponse.items.length > 0) {
          const searchResults: Video[] = searchResponse.items.map((item: any) => ({
            id: item.guid,
            title: item.title || 'Untitled Video',
            description: 'Search result from Bunny.net storage',
            thumbnail: BunnyVideoService.getThumbnailUrl(item.guid, item.thumbnailFileName),
            videoUrl: BunnyVideoService.getVideoPlayUrl(item.guid),
            duration: item.length || 0,
            views: item.views || Math.floor(Math.random() * 100000),
            likes: Math.floor(Math.random() * 5000),
            uploadDate: item.dateUploaded || new Date().toISOString(),
            author: {
              name: 'StreamVibe User',
              avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=1',
              subscribers: Math.floor(Math.random() * 1000000),
              verified: Math.random() > 0.5,
            },
            tags: ['video', 'streaming', 'search'],
            category: 'Entertainment',
            quality: ['720p', '1080p'],
          }));
          
          // Update videos with search results
          setVideos([...searchResults, ...MOCK_VIDEOS]);
        }
      } catch (error) {
        console.error('Error searching videos:', error);
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleVideoClick = (video: Video) => {
    setSelectedVideo(video);
    
    // Track video view
    if (user) {
      trackVideoView(video.id);
    }
  };

  const trackVideoView = async (videoId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('video-analytics', {
        body: {
          videoId,
          action: 'view',
          data: { views: 1 }
        }
      });
    } catch (error) {
      console.error('Error tracking view:', error);
    }
  };

  const handleClosePlayer = () => {
    setSelectedVideo(null);
  };

  const handleUpload = () => {
    setIsUploadModalOpen(true);
  };

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    setFilters({ ...filters, category });
  };

  const handleAdvancedSearch = (results: any[]) => {
    setSearchResults(results);
    setIsSearchMode(true);
    setIsAdvancedSearchOpen(false);
  };

  const resetSearch = () => {
    setIsSearchMode(false);
    setSearchResults([]);
    setFilters({ ...filters, query: '' });
  };

  const handleAddToPlaylist = (videoId: string) => {
    setSelectedVideoForPlaylist(videoId);
    setIsPlaylistModalOpen(true);
  };

  // Convert search results to Video format
  const convertSearchResults = (results: any[]): Video[] => {
    return results.map((item) => ({
      id: item.id,
      title: item.title,
      description: item.description || '',
      thumbnail: item.thumbnail_url || 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=400&h=225&dpr=1',
      videoUrl: BunnyVideoService.getVideoPlayUrl(item.bunny_video_id),
      duration: item.duration || 0,
      views: item.views || 0,
      likes: item.likes || 0,
      uploadDate: item.created_at,
      author: {
        name: item.profiles?.full_name || item.profiles?.username || 'Unknown Creator',
        avatar: item.profiles?.avatar_url || 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=1',
        subscribers: 0,
        verified: item.profiles?.verified || false,
      },
      tags: item.tags || [],
      category: item.category || 'Entertainment',
      quality: ['720p', '1080p'],
    }));
  };

  const displayVideos = isSearchMode ? convertSearchResults(searchResults) : filteredVideos;

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading StreamVibe...</p>
          {authError && (
            <p className="text-red-600 text-sm mt-2">Authentication Error: {authError}</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Header 
        onSearch={handleSearch} 
        onUpload={handleUpload}
        onShowTrending={() => setShowTrending(!showTrending)}
        onShowHistory={() => setShowHistory(!showHistory)}
        onShowAuth={() => setIsAuthModalOpen(true)}
        onShowProfile={() => setIsProfileModalOpen(true)}
        onShowAdvancedSearch={() => setIsAdvancedSearchOpen(true)}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 bg-clip-text text-transparent mb-4">
            Welcome to StreamVibe
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Discover, stream, and share amazing videos powered by Bunny.net's lightning-fast delivery network
          </p>
          
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
            <div className="bg-white rounded-xl shadow-md p-4">
              <div className="text-2xl font-bold text-purple-600">{videos.length}</div>
              <div className="text-gray-600 text-sm">Videos Available</div>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4">
              <div className="text-2xl font-bold text-blue-600">
                {videos.reduce((acc, video) => acc + video.views, 0).toLocaleString()}
              </div>
              <div className="text-gray-600 text-sm">Total Views</div>
            </div>
            <div className="bg-white rounded-xl shadow-md p-4">
              <div className="text-2xl font-bold text-green-600">4K</div>
              <div className="text-gray-600 text-sm">Ultra HD Quality</div>
            </div>
          </div>
        </div>

        {/* Search Results Header */}
        {isSearchMode && (
          <div className="mb-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">
              Search Results ({searchResults.length} videos found)
            </h2>
            <button onClick={resetSearch} className="text-purple-600 hover:text-purple-700">Clear search</button>
          </div>
        )}

        {/* Trending Section */}
        <TrendingSection 
          isVisible={showTrending} 
          onClose={() => setShowTrending(false)} 
        />

        {/* Advanced Filters */}
        <AdvancedFilters
          filters={filters}
          onFiltersChange={setFilters}
          isOpen={showAdvancedFilters}
          onToggle={() => setShowAdvancedFilters(!showAdvancedFilters)}
        />

        {/* Category Filter */}
        <CategoryFilter
          selectedCategory={selectedCategory}
          onCategoryChange={handleCategoryChange}
        />

        {/* Video Grid */}
        <VideoGrid
          videos={displayVideos}
          isLoading={isLoading}
          onVideoClick={handleVideoClick}
        />

        {/* Enhanced Stats Section */}
        {!isLoading && displayVideos.length > 0 && !isSearchMode && (
          <div className="mt-16 grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-white rounded-xl shadow-lg border border-purple-100">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {filteredVideos.length}
              </div>
              <div className="text-gray-600">Videos Available</div>
              <div className="text-sm text-gray-500 mt-1">Currently showing</div>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-lg border border-blue-100">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {filteredVideos.reduce((acc, video) => acc + video.views, 0).toLocaleString()}
              </div>
              <div className="text-gray-600">Total Views</div>
              <div className="text-sm text-gray-500 mt-1">Across all videos</div>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-lg border border-green-100">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {Math.floor(filteredVideos.reduce((acc, video) => acc + video.duration, 0) / 3600)}h
              </div>
              <div className="text-gray-600">Content Hours</div>
              <div className="text-sm text-gray-500 mt-1">Of premium content</div>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-lg border border-orange-100">
              <div className="text-3xl font-bold text-orange-600 mb-2">
                {filteredVideos.reduce((acc, video) => acc + video.likes, 0).toLocaleString()}
              </div>
              <div className="text-gray-600">Total Likes</div>
              <div className="text-sm text-gray-500 mt-1">Community engagement</div>
            </div>
          </div>
        )}
      </main>

      {/* Video Player Modal */}
      {selectedVideo && (
        <VideoPlayer video={selectedVideo} onClose={handleClosePlayer} />
      )}

      {/* Upload Modal */}
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* User Profile Modal */}
      <UserProfile
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />

      {/* Advanced Search Modal */}
      <AdvancedSearch
        isOpen={isAdvancedSearchOpen}
        onSearch={handleAdvancedSearch}
        onClose={() => setIsAdvancedSearchOpen(false)}
      />

      {/* Playlist Modal */}
      <PlaylistManager
        isOpen={isPlaylistModalOpen}
        onClose={() => {
          setIsPlaylistModalOpen(false);
          setSelectedVideoForPlaylist(null);
        }}
        videoId={selectedVideoForPlaylist}
      />
    </div>
  );
}

export default App;