import React, { useEffect, useRef, useState } from 'react';
import { X, ThumbsUp, ThumbsDown, Share, Download, Eye, Calendar, Bell, MoreHorizontal, MessageCircle } from 'lucide-react';
import { Video, Comment } from '../types/video';
import { BunnyVideoService } from '../services/bunnyApi';

interface VideoPlayerProps {
  video: Video;
  onClose: () => void;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({ video, onClose }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [showDescription, setShowDescription] = useState(false);
  const [comments] = useState<Comment[]>([
    {
      id: '1',
      author: {
        name: 'John Doe',
        avatar: 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
      },
      content: 'Amazing video! Really enjoyed watching this. The quality is fantastic.',
      timestamp: '2 hours ago',
      likes: 24,
      replies: [],
    },
    {
      id: '2',
      author: {
        name: 'Sarah Wilson',
        avatar: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
      },
      content: 'Thanks for sharing this! Very informative and well-produced.',
      timestamp: '5 hours ago',
      likes: 12,
      replies: [],
    },
  ]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [onClose]);

  const formatViews = (views: number): string => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M views`;
    } else if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const formatSubscribers = (count: number): string => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M subscribers`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K subscribers`;
    }
    return `${count} subscribers`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-95 z-50 flex items-center justify-center p-4">
      <div className="w-full max-w-7xl mx-auto bg-white rounded-lg overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-gray-50">
          <h2 className="text-xl font-semibold text-gray-900 truncate flex-1 mr-4">{video.title}</h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-200 rounded-full transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 p-6">
          {/* Video Player */}
          <div className="xl:col-span-3">
            <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden mb-6">
              <iframe
                ref={iframeRef}
                src={BunnyVideoService.getVideoPlayUrl(video.id)}
                className="w-full h-full"
                allowFullScreen
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
            </div>

            {/* Video Info */}
            <div className="space-y-4">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{video.title}</h1>
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center space-x-4 text-gray-600">
                    <div className="flex items-center space-x-2">
                      <Eye className="h-5 w-5" />
                      <span>{formatViews(video.views)}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-5 w-5" />
                      <span>{formatDate(video.uploadDate)}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setIsLiked(!isLiked)}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                        isLiked ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      <ThumbsUp className="h-5 w-5" />
                      <span>{(video.likes + (isLiked ? 1 : 0)).toLocaleString()}</span>
                    </button>
                    <button
                      onClick={() => setIsDisliked(!isDisliked)}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                        isDisliked ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      <ThumbsDown className="h-5 w-5" />
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">
                      <Share className="h-5 w-5" />
                      <span>Share</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">
                      <Download className="h-5 w-5" />
                      <span>Download</span>
                    </button>
                    <button className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">
                      <MoreHorizontal className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Channel Info */}
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <img
                    src={video.author.avatar}
                    alt={video.author.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-semibold text-gray-900 flex items-center space-x-2">
                      <span>{video.author.name}</span>
                      {video.author.verified && (
                        <span className="text-blue-500">✓</span>
                      )}
                    </h3>
                    <p className="text-sm text-gray-500">{formatSubscribers(video.author.subscribers)}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsSubscribed(!isSubscribed)}
                  className={`flex items-center space-x-2 px-6 py-2 rounded-lg font-medium transition-colors ${
                    isSubscribed
                      ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      : 'bg-red-600 text-white hover:bg-red-700'
                  }`}
                >
                  <Bell className="h-5 w-5" />
                  <span>{isSubscribed ? 'Subscribed' : 'Subscribe'}</span>
                </button>
              </div>

              {/* Description */}
              <div className="bg-gray-50 rounded-lg p-4">
                <button
                  onClick={() => setShowDescription(!showDescription)}
                  className="text-left w-full"
                >
                  <p className={`text-gray-700 ${showDescription ? '' : 'line-clamp-3'}`}>
                    {video.description}
                  </p>
                  <span className="text-purple-600 font-medium mt-2 inline-block">
                    {showDescription ? 'Show less' : 'Show more'}
                  </span>
                </button>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mt-4">
                  {video.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-block bg-purple-100 text-purple-700 text-sm px-3 py-1 rounded-full cursor-pointer hover:bg-purple-200 transition-colors"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Comments Section */}
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <h3 className="text-xl font-semibold text-gray-900">Comments</h3>
                  <span className="text-gray-500">{comments.length}</span>
                </div>

                {/* Add Comment */}
                <div className="flex space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full flex items-center justify-center">
                    <span className="text-white font-medium">U</span>
                  </div>
                  <div className="flex-1">
                    <textarea
                      placeholder="Add a comment..."
                      className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                      rows={3}
                    />
                    <div className="flex justify-end space-x-2 mt-2">
                      <button className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                        Cancel
                      </button>
                      <button className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
                        Comment
                      </button>
                    </div>
                  </div>
                </div>

                {/* Comments List */}
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex space-x-3">
                      <img
                        src={comment.author.avatar}
                        alt={comment.author.name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="font-medium text-gray-900">{comment.author.name}</span>
                          <span className="text-sm text-gray-500">{comment.timestamp}</span>
                        </div>
                        <p className="text-gray-700 mb-2">{comment.content}</p>
                        <div className="flex items-center space-x-4">
                          <button className="flex items-center space-x-1 text-gray-500 hover:text-purple-600 transition-colors">
                            <ThumbsUp className="h-4 w-4" />
                            <span>{comment.likes}</span>
                          </button>
                          <button className="text-gray-500 hover:text-purple-600 transition-colors">
                            <ThumbsDown className="h-4 w-4" />
                          </button>
                          <button className="text-gray-500 hover:text-purple-600 transition-colors">
                            Reply
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Related Videos */}
          <div className="xl:col-span-1">
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-4">Up Next</h3>
              <div className="space-y-3">
                {/* Related video items would go here */}
                <div className="text-center text-gray-500 py-8">
                  <MessageCircle className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                  <p>Related videos will appear here</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};