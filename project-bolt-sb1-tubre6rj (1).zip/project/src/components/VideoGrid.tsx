import React from 'react';
import { VideoCard } from './VideoCard';
import { Video } from '../types/video';
import { Loader2 } from 'lucide-react';

interface VideoGridProps {
  videos: Video[];
  isLoading?: boolean;
  onVideoClick: (video: Video) => void;
}

export const VideoGrid: React.FC<VideoGridProps> = ({ 
  videos, 
  isLoading = false, 
  onVideoClick 
}) => {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="h-12 w-12 text-purple-500 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading amazing videos...</p>
        </div>
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <div className="w-24 h-24 bg-gradient-to-r from-purple-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">🎬</span>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No videos found</h3>
          <p className="text-gray-600">Try adjusting your search or browse our featured content.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {videos.map((video) => (
        <VideoCard
          key={video.id}
          video={video}
          onClick={onVideoClick}
        />
      ))}
    </div>
  );
};