import React, { useState } from 'react';
import {
  Play,
  Eye,
  Calendar,
  ThumbsUp,
  Clock,
  CheckCircle,
  MoreVertical,
  Share,
  Bookmark,
  Flag,
} from 'lucide-react';
import { Video } from '../types/video';

interface VideoCardProps {
  video: Video;
  onClick: (video: Video) => void;
  variant?: 'default' | 'compact' | 'large';
}

export const VideoCard: React.FC<VideoCardProps> = ({
  video,
  onClick,
  variant = 'default',
}) => {
  const [showMenu, setShowMenu] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds
        .toString()
        .padStart(2, '0')}`;
    }
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const formatViews = (views: number): string => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M views`;
    } else if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K views`;
    }
    return `${views} views`;
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return '1 day ago';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  };

  const cardClasses = {
    default:
      'group cursor-pointer bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1',
    compact:
      'group cursor-pointer bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200',
    large:
      'group cursor-pointer bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2',
  };

  return (
    <div
      className={cardClasses[variant]}
      onClick={() => onClick(video)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Thumbnail Container */}
      <div className="relative overflow-hidden rounded-t-xl aspect-video">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />

        {/* Play Overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
          <div
            className={`transition-all duration-300 ${
              isHovered ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
            }`}
          >
            <div className="w-16 h-16 bg-white bg-opacity-95 rounded-full flex items-center justify-center shadow-lg">
              <Play
                className="h-8 w-8 text-purple-600 ml-1"
                fill="currentColor"
              />
            </div>
          </div>
        </div>

        {/* Duration Badge */}
        <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-sm px-2 py-1 rounded font-medium">
          {formatDuration(video.duration)}
        </div>

        {/* Quality Badge */}
        {video.quality && video.quality.includes('4K') && (
          <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded font-bold">
            4K
          </div>
        )}

        {/* Live Badge */}
        {video.isLive && (
          <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded font-bold flex items-center space-x-1">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span>LIVE</span>
          </div>
        )}

        {/* Premium Badge */}
        {video.isPremium && (
          <div className="absolute top-2 right-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs px-2 py-1 rounded font-bold">
            PREMIUM
          </div>
        )}
      </div>

      {/* Video Info */}
      <div className="p-4">
        <div className="flex space-x-3">
          {/* Author Avatar */}
          <div className="relative flex-shrink-0">
            <img
              src={video.author.avatar}
              alt={video.author.name}
              className="w-10 h-10 rounded-full object-cover"
            />
            {video.author.verified && (
              <CheckCircle className="absolute -bottom-1 -right-1 w-4 h-4 text-blue-500 bg-white rounded-full" />
            )}
          </div>

          {/* Video Details */}
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 line-clamp-2 mb-2 group-hover:text-purple-600 transition-colors leading-tight">
              {video.title}
            </h3>

            <div className="flex items-center space-x-1 mb-2">
              <p className="text-sm text-gray-600">{video.author.name}</p>
              {video.author.verified && (
                <CheckCircle className="w-4 h-4 text-blue-500" />
              )}
            </div>

            <div className="flex items-center space-x-4 text-sm text-gray-500 mb-2">
              <div className="flex items-center space-x-1">
                <Eye className="h-4 w-4" />
                <span>{formatViews(video.views)}</span>
              </div>

              <div className="flex items-center space-x-1">
                <ThumbsUp className="h-4 w-4" />
                <span>{video.likes.toLocaleString()}</span>
              </div>

              <div className="flex items-center space-x-1">
                <Calendar className="h-4 w-4" />
                <span>{formatDate(video.uploadDate)}</span>
              </div>
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-1">
              {video.tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="inline-block bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded-full"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>

          {/* More Options */}
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowMenu(!showMenu);
              }}
              className="p-1 text-gray-400 hover:text-gray-600 transition-colors opacity-0 group-hover:opacity-100"
            >
              <MoreVertical className="h-5 w-5" />
            </button>

            {showMenu && (
              <div className="absolute right-0 top-8 w-48 bg-white rounded-lg shadow-xl border border-gray-200 py-2 z-10">
                <button className="flex items-center space-x-3 w-full px-4 py-2 text-gray-700 hover:bg-gray-50 text-left">
                  <Bookmark className="h-4 w-4" />
                  <span>Save to Watch Later</span>
                </button>
                <button className="flex items-center space-x-3 w-full px-4 py-2 text-gray-700 hover:bg-gray-50 text-left">
                  <Share className="h-4 w-4" />
                  <span>Share</span>
                </button>
                <button className="flex items-center space-x-3 w-full px-4 py-2 text-gray-700 hover:bg-gray-50 text-left">
                  <Flag className="h-4 w-4" />
                  <span>Report</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
