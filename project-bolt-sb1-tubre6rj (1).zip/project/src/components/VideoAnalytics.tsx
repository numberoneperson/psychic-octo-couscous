import React, { useState, useEffect } from 'react';
import { BarChart3, Eye, ThumbsUp, MessageCircle, Share, TrendingUp, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

interface AnalyticsData {
  totalViews: number;
  totalLikes: number;
  totalComments: number;
  totalShares: number;
  dailyViews: Array<{ date: string; views: number }>;
  topVideos: Array<{ id: string; title: string; views: number; likes: number }>;
}

interface VideoAnalyticsProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoAnalytics: React.FC<VideoAnalyticsProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [timeRange, setTimeRange] = useState('7d');

  useEffect(() => {
    if (isOpen && user) {
      loadAnalytics();
    }
  }, [isOpen, user, timeRange]);

  const loadAnalytics = async () => {
    if (!user) return;

    setLoading(true);
    try {
      // Get user's videos
      const { data: videos, error: videosError } = await supabase
        .from('user_videos')
        .select('id, title, views, likes')
        .eq('user_id', user.id)
        .order('views', { ascending: false });

      if (videosError) throw videosError;

      // Calculate date range
      const endDate = new Date();
      const startDate = new Date();
      switch (timeRange) {
        case '7d':
          startDate.setDate(endDate.getDate() - 7);
          break;
        case '30d':
          startDate.setDate(endDate.getDate() - 30);
          break;
        case '90d':
          startDate.setDate(endDate.getDate() - 90);
          break;
      }

      // Get analytics data
      const { data: analyticsData, error: analyticsError } = await supabase
        .from('video_analytics')
        .select('*')
        .in('video_id', videos?.map(v => v.id) || [])
        .gte('date', startDate.toISOString().split('T')[0])
        .lte('date', endDate.toISOString().split('T')[0])
        .order('date', { ascending: true });

      if (analyticsError) throw analyticsError;

      // Process data
      const totalViews = videos?.reduce((sum, video) => sum + video.views, 0) || 0;
      const totalLikes = videos?.reduce((sum, video) => sum + video.likes, 0) || 0;
      const totalComments = 0; // Would calculate from comments table
      const totalShares = 0; // Would calculate from shares

      // Group daily views
      const dailyViewsMap = new Map();
      analyticsData?.forEach(item => {
        const existing = dailyViewsMap.get(item.date) || 0;
        dailyViewsMap.set(item.date, existing + item.views);
      });

      const dailyViews = Array.from(dailyViewsMap.entries()).map(([date, views]) => ({
        date,
        views
      }));

      const topVideos = videos?.slice(0, 5) || [];

      setAnalytics({
        totalViews,
        totalLikes,
        totalComments,
        totalShares,
        dailyViews,
        topVideos
      });
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <BarChart3 className="h-6 w-6 text-purple-600" />
            <h2 className="text-2xl font-bold text-gray-900">Video Analytics</h2>
          </div>
          <div className="flex items-center space-x-4">
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 90 days</option>
            </select>
            <button
              onClick={onClose}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-8 h-8 bg-purple-500 rounded-full animate-spin"></div>
            </div>
          ) : analytics ? (
            <div className="space-y-8">
              {/* Overview Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-blue-600 text-sm font-medium">Total Views</p>
                      <p className="text-3xl font-bold text-blue-900">
                        {analytics.totalViews.toLocaleString()}
                      </p>
                    </div>
                    <Eye className="h-8 w-8 text-blue-500" />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-red-50 to-red-100 rounded-xl p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-red-600 text-sm font-medium">Total Likes</p>
                      <p className="text-3xl font-bold text-red-900">
                        {analytics.totalLikes.toLocaleString()}
                      </p>
                    </div>
                    <ThumbsUp className="h-8 w-8 text-red-500" />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-600 text-sm font-medium">Comments</p>
                      <p className="text-3xl font-bold text-green-900">
                        {analytics.totalComments.toLocaleString()}
                      </p>
                    </div>
                    <MessageCircle className="h-8 w-8 text-green-500" />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-purple-600 text-sm font-medium">Shares</p>
                      <p className="text-3xl font-bold text-purple-900">
                        {analytics.totalShares.toLocaleString()}
                      </p>
                    </div>
                    <Share className="h-8 w-8 text-purple-500" />
                  </div>
                </div>
              </div>

              {/* Views Chart */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-purple-600" />
                  Daily Views
                </h3>
                <div className="h-64 flex items-end space-x-2">
                  {analytics.dailyViews.map((day, index) => {
                    const maxViews = Math.max(...analytics.dailyViews.map(d => d.views));
                    const height = maxViews > 0 ? (day.views / maxViews) * 100 : 0;
                    
                    return (
                      <div key={index} className="flex-1 flex flex-col items-center">
                        <div
                          className="w-full bg-gradient-to-t from-purple-500 to-purple-300 rounded-t"
                          style={{ height: `${height}%`, minHeight: '4px' }}
                          title={`${day.views} views on ${new Date(day.date).toLocaleDateString()}`}
                        />
                        <span className="text-xs text-gray-500 mt-2">
                          {new Date(day.date).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Top Videos */}
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performing Videos</h3>
                <div className="space-y-4">
                  {analytics.topVideos.map((video, index) => (
                    <div key={video.id} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{video.title}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span className="flex items-center space-x-1">
                            <Eye className="h-4 w-4" />
                            <span>{video.views.toLocaleString()} views</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <ThumbsUp className="h-4 w-4" />
                            <span>{video.likes.toLocaleString()} likes</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <BarChart3 className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No analytics data</h3>
              <p className="text-gray-600">Upload some videos to see your analytics</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};