import React, { useState, useEffect } from 'react';
import { Plus, X, Play, Lock, Globe, Trash2, Edit3 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';

interface Playlist {
  id: string;
  title: string;
  description: string;
  is_public: boolean;
  video_count: number;
  total_duration: number;
  created_at: string;
}

interface PlaylistManagerProps {
  isOpen: boolean;
  onClose: () => void;
  videoId?: string;
}

export const PlaylistManager: React.FC<PlaylistManagerProps> = ({ 
  isOpen, 
  onClose, 
  videoId 
}) => {
  const { user } = useAuth();
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newPlaylist, setNewPlaylist] = useState({
    title: '',
    description: '',
    is_public: true
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && user) {
      loadPlaylists();
    }
  }, [isOpen, user]);

  const loadPlaylists = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('playlists')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setPlaylists(data);
    }
  };

  const createPlaylist = async () => {
    if (!user || !newPlaylist.title.trim()) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('playlists')
      .insert({
        user_id: user.id,
        title: newPlaylist.title,
        description: newPlaylist.description,
        is_public: newPlaylist.is_public
      })
      .select()
      .single();

    if (!error && data) {
      setPlaylists([data, ...playlists]);
      setNewPlaylist({ title: '', description: '', is_public: true });
      setIsCreating(false);
      
      // Add video to playlist if videoId provided
      if (videoId) {
        await addVideoToPlaylist(data.id);
      }
    }
    setLoading(false);
  };

  const addVideoToPlaylist = async (playlistId: string) => {
    if (!videoId) return;

    const { error } = await supabase
      .from('playlist_videos')
      .insert({
        playlist_id: playlistId,
        video_id: videoId,
        position: 0
      });

    if (!error) {
      // Update playlist video count
      await supabase
        .from('playlists')
        .update({ video_count: playlists.find(p => p.id === playlistId)?.video_count + 1 || 1 })
        .eq('id', playlistId);
      
      loadPlaylists();
    }
  };

  const deletePlaylist = async (playlistId: string) => {
    const { error } = await supabase
      .from('playlists')
      .delete()
      .eq('id', playlistId);

    if (!error) {
      setPlaylists(playlists.filter(p => p.id !== playlistId));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-900">
            {videoId ? 'Save to Playlist' : 'Manage Playlists'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {/* Create New Playlist */}
          {isCreating ? (
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <h3 className="font-semibold text-gray-900 mb-4">Create New Playlist</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  value={newPlaylist.title}
                  onChange={(e) => setNewPlaylist({ ...newPlaylist, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="Playlist title"
                />
                <textarea
                  value={newPlaylist.description}
                  onChange={(e) => setNewPlaylist({ ...newPlaylist, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                  rows={3}
                  placeholder="Description (optional)"
                />
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="is_public"
                    checked={newPlaylist.is_public}
                    onChange={(e) => setNewPlaylist({ ...newPlaylist, is_public: e.target.checked })}
                    className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                  />
                  <label htmlFor="is_public" className="text-sm text-gray-700">
                    Make playlist public
                  </label>
                </div>
                <div className="flex space-x-3">
                  <button
                    onClick={createPlaylist}
                    disabled={loading || !newPlaylist.title.trim()}
                    className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Creating...' : 'Create'}
                  </button>
                  <button
                    onClick={() => setIsCreating(false)}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setIsCreating(true)}
              className="w-full flex items-center justify-center space-x-2 p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-purple-400 hover:bg-purple-50 transition-colors mb-6"
            >
              <Plus className="h-5 w-5 text-gray-400" />
              <span className="text-gray-600">Create New Playlist</span>
            </button>
          )}

          {/* Existing Playlists */}
          <div className="space-y-3">
            {playlists.map((playlist) => (
              <div
                key={playlist.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center space-x-3 flex-1">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                    <Play className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h3 className="font-semibold text-gray-900">{playlist.title}</h3>
                      {playlist.is_public ? (
                        <Globe className="h-4 w-4 text-green-500" />
                      ) : (
                        <Lock className="h-4 w-4 text-gray-500" />
                      )}
                    </div>
                    <p className="text-sm text-gray-600">
                      {playlist.video_count} videos • {new Date(playlist.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {videoId && (
                    <button
                      onClick={() => addVideoToPlaylist(playlist.id)}
                      className="px-3 py-1 bg-purple-500 text-white text-sm rounded hover:bg-purple-600 transition-colors"
                    >
                      Add
                    </button>
                  )}
                  <button
                    onClick={() => deletePlaylist(playlist.id)}
                    className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {playlists.length === 0 && !isCreating && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Play className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No playlists yet</h3>
              <p className="text-gray-600">Create your first playlist to organize your favorite videos</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};